function About() {
  return (
    <section className="about">
      <h1>About Me</h1>
      <p>
        Hello, my name is Ryan. I am a middle school student, and one of my hobbies
        is gaming, especially story-based games like RDR2 and GTA V.
      </p>
      <p>
        I love gaming because I enjoy exploring virtual worlds and experiencing
        deep stories.
      </p>
    </section>
  );
}

export default About;