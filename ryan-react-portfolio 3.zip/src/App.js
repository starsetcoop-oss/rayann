import About from "./components/About";

function App() {
  return (
    <div className="app">
      <About />
    </div>
  );
}

export default App;